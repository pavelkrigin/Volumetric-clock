# ColorClock
ColorClock is a Modern Clock Designed By Neumorphic Effect

Neumorphism is a form of minimalism characterized by a soft and light look, often using pastel colors with low contrast. Elements are usually the same color as the background, and are only distinguished by shadows and highlights surrounding the element.
